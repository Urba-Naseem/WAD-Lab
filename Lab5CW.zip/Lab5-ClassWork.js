console.log("WebAppDev");
 fullName="Urba Naseem"
 price=100;
 radius=14;
 x=null;
 y=undefined;
 console.log(fullName);

 var name = "John";
let age_John = 25; 
const isStudent = true; 
console.log(typeof('isStudent'));

var name = "Urba";
console.log(name);

var name = "Ali"; 
console.log(name); 
name = "Sara"; 
console.log(name); 

if (true) {
    var test = "Inside block";
}
console.log(test);


const pii = 3.1416;
console.log(pii); // Output: 3.1416
if (true) {
    const city = "Lahore";
    console.log(city); // Output: Lahore
}
let a = 10;
let b = 5;
console.log(a + b); // Addition
console.log(a - b); // Subtraction
console.log(a * b); // Multiplication
console.log(a / b); // Division
console.log(a % b); // Modulus

let score = 80;
if (score >= 50) {
    console.log("Pass");
} else {
    console.log("Fail");
}
for (let i = 0; i < 5; i++) {
    console.log("Iteration: " + i);
}
let age = 25;  
let pi = 3.1416;  
console.log("Number:", age); // Output: Number: 25
console.log("Float Number:", pi); // Output: Float Number: 3.1416
let Student = true;  
let hasGraduated = false;  
console.log("Boolean:", Student); // Output: Boolean: true
console.log("Boolean:", hasGraduated); // Output: Boolean: false

let emptyValue = null;  
console.log("Null:", emptyValue); // Output: Null: null
let notAssigned;  
console.log("Undefined:", notAssigned); 


const student={
    FullName:"Urba Naseem",
    age:20,
    cgpa:4.00,
    isPass:true,
};
student["age"]=student["age"]+1;
console.log(student["age"]);

let c=3;
let d=6;
console.log("c=  ",c , "d=  ",d);
console.log("c++ =  ",c++);
console.log("c =  ",c);


    var fruitType = prompt("Which fruit do you want?"); 
    switch (fruitType) {
        case 'orange':
            console.log('Orange costs 60rs per kilo.');
            break;
        case 'apple':
            console.log('Apple costs 180rs per kilo.');
            break;
        case 'banana':
            console.log('Bananas cost 35rs per kilo.');
            break;
        case 'guava':
            console.log('Guava costs 80rs per kilo.');
            break;
        case 'mango':
            console.log('Mangoes cost 300rs per dozen.');
            break;
        case 'papaya':
            console.log('Mango and Papaya together cost 300rs per dozen.');
            break;
        default:
            console.log(`${fruitType} is out of stock today, it will be available tomorrow.`);
    }
    console.log("Would you like anything else?");

//fro in loop
    const person = { 
        name: "Urba Naseem",
        age: 20, 
        city: "Rawalpindi" };

for (let key in person) {
    console.log(key + ": " + person[key]);
}

//for of loop
const numbers = [10, 20, 30];
for (let num of numbers) {
    console.log(num);
}