//1.Find even numbers using for of loop in an array.
let num_list=[1,2,3,4,5,6,7,8,9,10];
let even=[];
for(let num of num_list){
     if(num%2==0){
      even.push(num);  
     }
}
console.log(even);

//2.Find max and min in an array using for of loop.
let numbers=[1,2,3,4,5];
let max=numbers[0];
let min=numbers[0];
for(let num of numbers){
    if(num>max){
        max=num;
    }
    if(num<min){
        min=num;
    }
}
console.log("Maximum value:", max);
console.log("Minimum value:", min);

//3. Convert each string in an array to uppercase using for of loop.
let words=["under", "the", "same", "sky"];
let UCwords=[];
for(let word of words){
    UCwords.push(word.toUpperCase());
}
console.log("UpperCaseWords:"  , UCwords);

//4.Create an array to store Software houses name.
let softwareHouses = ["Systems Ltd", "Ovex Technologies", "Averox", "Amazon", "DPL","The Square Peg"];
let updatedHouses = modifySoftwareHouses(softwareHouses);

function modifySoftwareHouses(softwareHouses){
    softwareHouses.shift();

    let midIndex =(6/2);
    softwareHouses.splice(midIndex,1,"Techuire");

    softwareHouses.push("Emumba");  
    return softwareHouses;
}
console.log("Updated Software Houses:", updatedHouses);

//5.Create a function that accepts string as argument and return number of vowels in the string.
function countVowels(str){
   let vowels="aeiouAEIOU";
   let count=0;
   for(let char of str){
        if(vowels.includes(char)){
            count++;
        }
   }
   return count;
}
console.log("Number of Vowels in ice-cream: ",countVowels("ice-cream"));
console.log("Number of Vowels in coffee: ",countVowels("coffee"));
console.log("Number of Vowels in chocolate: ",countVowels("chocolate"));

//6.With arrow Function:
const count_Vowels=(str)=>{
    let vowels="aeiouAEIOU";
    let count=0;
    for(let char of str){
         if(vowels.includes(char)){
             count++;
         }
    }
    return count;
 }
 console.log("with arrow Function:");
 console.log("Number of Vowels in ice-cream: ",count_Vowels("ice-cream"));
 console.log("Number of Vowels in coffee: ",count_Vowels("coffee"));
 console.log("Number of Vowels in chocolate: ",count_Vowels("chocolate"));
 
 //7.Create an array and print square of each number in an array using for each loop.
 let number = [2,4,6,8,10];
    number.forEach(num=>{console.log(num*num)})

//8.Create an array of students, filter out the marks greater than 50.
let Students=[
    {St_name: "Urba", marks: 57},
    {St_name: "Shiza", marks: 98},
    {St_name: "Fasiha", marks: 32},
    {St_name: "Khansa", marks: 23},
    {St_name: "Syeda Ayesha", marks: 89},

]
let result=Students.filter(St=>St.marks>50);
console.log("Students with marks greater than 50:", result);


//9.Take an input n from user and create a new array of numbers.
let n = prompt("Enter the number of elements:"); 
let numberss = []; 

for (let i = 0; i < n; i++) {
    let num = prompt("Enter number :"); 
    numberss.push(+num);
}

console.log("Your Array:", numberss);

//10.Use reduce method to calculate a product of all numbers in an array.

let arr = [2, 3, 4, 5];

let product = arr.reduce((acc, num) => acc * num, 1);

console.log("Product of all numbers:", product);