var container = document.getElementsByClassName("container");
var text = ["Name: Urba Naseem", "Sap-id: 52920", "Department: Bs-Cs4"];
for (var i = 0; i < container.length; i++) 
{
    container[i].innerHTML = text[i];
}
