// Classwork

//SLICE:
let numbers=[1,2,3,4,5];
let sliced=numbers.slice(1,4);
console.log(sliced);
console.log(numbers);
//SPLICE:
let fruits=["Apple", "Banana", "Cheery" , "Pineapple"];
console.log(fruits);
let spliced=fruits.splice(1,2,"Blueberry","Mango");
console.log(spliced);
console.log(fruits);
//TO-STRING:
let Products=["laptop","phone","charger"];
let result=Products.toString();
console.log(result);
//SHIFT
let color=["Red","yellow","green"];
let removed= color.shift();
console.log(removed);
console.log(color);
let add=color.unshift("Pink","grey");
console.log(color);
console.log(add);
//CONCAT:
let arr1=[1,2,3];
let arr2=[4,5,6];
console.log(arr1.concat(arr2));
//ARROW METHOD:
let Add=(a,b)=>(a+b);
console.log(Add(3,4));
//FOR-EACH METHOD:
let list=[1,2,3,4];
list.forEach(num=>{
    console.log(num*2); 
});
//REDUCED METHOD:
let number=[1,2,3,4,5];
let sum=number.reduce((acc,num)=>acc+num,0);
console.log("sum:" ,sum);
//FILTER METHOD:
let num_list=[1,2,3,4,5,6,7,8,9,10];
let evens = num_list.filter(num=>num%2===0);
console.log("Even numbers in the list:" ,evens)
//MAP:
let numb = [1, 2, 3, 4];

let doubled = numb.map(num => num * 2);

console.log(doubled); 
console.log(numb);