// Task#1. Chect type of BIGINT and Symbol
let bigIntNum = 327589180587654323456789098765432n; // BigInt
let symbolVar = Symbol("Happy") // Symbol

console.log(typeof bigIntNum); // Output: bigint
console.log(typeof symbolVar); // Output: symbol


// Task#2.Store Information of Product 
const Product = {
    id: 101,
    name: "PakWheels waterless and Glass Cleaner",
    beforeprice: "Rs-1198",
    Discount: "20%",
    Afterprice: "Rs-958",
    brand: "Wheel Entine",
    inStock: true
};

console.log(Product);

// Task#3.create Instagram profile
const InstagramProfile = {
    username:"i._.urba22",
    posts: 0,
    followers: 226,
    following: 355,
    bio: "Throw me to the wolves and I'll return leading the pack(^.^)"
};

console.log(InstagramProfile);

// Task#4. Apply unary operators
let a = 30;

console.log(a++); // Post-increment (Prints 30, then increments)
console.log(++a); // Pre-increment (Increments first, then prints)
console.log(a--); // Post-decrement (Prints current value, then decrements)
console.log(--a); // Pre-decrement (Decrements first, then prints)

// Task#5. Check if a number entered by the user is a multiple of 3
let userNum = prompt("Kindly, Enter a number:");
userNum = Number(userNum); // Convert input to number

if (userNum % 3 === 0) {
    console.log(userNum + " is a multiple of 3.");
} else {
    console.log(userNum + " is NOT a multiple of 3.");
}

// Task#6. Assign grades based on student scores
let score = prompt("Enter student score:");
score = Number(score);

console.log("Student Attained: ")

if (score >= 80) {
    console.log("Grade: A");
} else if (score >= 70) {
    console.log("Grade: B");
} else if (score >= 60) {
    console.log("Grade: C");
} else if (score >= 50) {
    console.log("Grade: D");
} else {
    console.log("Grade: F");
}