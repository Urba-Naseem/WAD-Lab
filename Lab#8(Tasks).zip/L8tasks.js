//Task1
function changeClassName() {
var para = document.getElementById("Para1");

    console.log("Old class-name:", para.className);

    para.className = "Graph-Grid(n)";
    console.log("New class-name:", para.className);
}

 
//Task2
const logInButton = document.createElement("button");
    logInButton.textContent = "Log-In";
    logInButton.style.backgroundColor = "blue";  
    logInButton.style.color = "white";  
    logInButton.style.fontSize = "20px";  // Font size
    logInButton.style.padding = "15px 30px";  

    logInButton.onmouseover=()=> {
        logInButton.style.backgroundColor = "darkblue"; 
        console.log("Button inserted outside the body tag as first element");
    };
  
      logInButton.onmouseout=()=> {
        logInButton.style.backgroundColor = "blue";  
    };
document.documentElement.insertBefore(logInButton, document.body);

//Task3
function addNewStyle() {
    const pElement = document.querySelector('.class1');

    // Add the new class to the existing class list of the <p> element
    pElement.classList.toggle('newStyle');
}